#!/bin/bash
java -jar dist/TheScopeReport.jar