package scopereport2.pkg0;

import java.util.logging.Level;
import java.util.logging.Logger;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

/*
Programmer: Zachary Dorow

 */
public class MobileApplications {
    private static final Logger LOG = Logger.getLogger(MobileApplications.class.getName());
    
    private final int groupId;

    private JPApiCalls api;
    
    public MobileApplications (int DgroupId) {      
        groupId = DgroupId;
}

    public String MobileAppScope(int DgroupId) {
        try {
                        //Getting all the applcations
            JSONObject jsonMobileApps = new JSONObject(api.get("mobiledeviceapplications"));
            JSONArray jsonAppArray = jsonMobileApps.getJSONArray("mobile_device_applications");
           
            //Getting the scope of all the applications
          for(int count=0; count<jsonAppArray.length(); count++){
            JSONObject dataObj2 = (JSONObject) jsonAppArray.get(count);
            int DappId = dataObj2.getInt("id");
            String AppName = dataObj2.getString("name");
            JSONObject jsonAPPScope = new JSONObject(api.get("mobiledeviceapplications/id/" + DappId + "/subset/scope"));
            
            //Checking the mobile device group scope
           JSONObject jsonGroupAPP = jsonAPPScope.getJSONObject("mobile_device_application");
           JSONObject jsonAppScope = jsonGroupAPP.getJSONObject("scope");
           JSONArray MobileGroupScopeARRAY = jsonAppScope.getJSONArray("mobile_device_groups");
           
           String MobileGroupScope = MobileGroupScopeARRAY.toString();
           
            // Comparing ID of the mobile device group           
            if (!"[]".equals(MobileGroupScope)){
            
                for(int c=0; c < MobileGroupScopeARRAY.length(); c++){
                    JSONObject MobileGroupScopeObject = (JSONObject) MobileGroupScopeARRAY.get(c);
                    int ScopeDgroupId = MobileGroupScopeObject.getInt("id");
                                String MobileGroupSLIM = MobileGroupScope.replace("[", "").replace("]", "");
                                String[] MobileGroupARRAY = MobileGroupSLIM.split("name:");
                    for (String MobileGroupARRAY1 : MobileGroupARRAY) {
                        if(DgroupId== ScopeDgroupId){

                            return AppName;
                        }
                    }          
                            }
                    }
            }
            
        } catch (JPApiException | JSONException ex) {
            Logger.getLogger(MobileApplications.class.getName()).log(Level.SEVERE, null, ex);
        }
       return null; 
    }
    
}
