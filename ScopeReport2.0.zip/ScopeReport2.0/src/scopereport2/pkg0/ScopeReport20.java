/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package scopereport2.pkg0;


import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.time.format.DateTimeFormatter;

import java.util.Arrays;
import javafx.scene.image.Image;
import java.util.List;
import javafx.event.ActionEvent;
import javafx.geometry.HPos;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleGroup;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.stage.Stage;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.application.Application;
import static javafx.application.Application.launch;
import javafx.concurrent.Task;

import javafx.geometry.Pos;
import org.json.JSONArray;
import org.json.JSONException;

import org.json.JSONObject;
/**
 *
 * @author ZD
 */
public class ScopeReport20 extends Application {

        public static void main(String[] args)
    {
        launch(args);
    }

//Radio button naming   
RadioButton ComputerGroupsButton = new RadioButton("Computer Groups");
RadioButton MobileGroupsButton = new RadioButton("Mobile Groups");
RadioButton UserGroupsButton = new RadioButton("User Groups");
    
private JPApiCalls api;
private MobileApplications Mapps;


    @Override
    public void start(Stage primaryStage) throws JPApiException {
    
    ToggleGroup DeviceGroup = new ToggleGroup();
    DeviceGroup.getToggles().addAll(ComputerGroupsButton, MobileGroupsButton, UserGroupsButton);
    ComputerGroupsButton.setSelected(false);
    MobileGroupsButton.setSelected(true);
    UserGroupsButton.setSelected(false);
    
        Font font = new Font("Dialog", 18);
        Font font1 = new Font("Dialog Bold", 14);
                
        Label NamesLabel = new Label("Organize scope report by:");
        NamesLabel.setFont(font);
        NamesLabel.setLineSpacing(20);
        GridPane.setHalignment(NamesLabel, HPos.CENTER);
        
        Label JamfProLabel = new Label("Jamf Pro URL:");
        JamfProLabel.setFont(font);
        JamfProLabel.setLineSpacing(20);
        GridPane.setHalignment(JamfProLabel, HPos.CENTER);
        
        Label JamfProUsernameLabel = new Label("Jamf Pro Username:");
        JamfProUsernameLabel.setFont(font);
        JamfProUsernameLabel.setLineSpacing(20);
        GridPane.setHalignment(JamfProUsernameLabel, HPos.CENTER);
        
        Label JamfProPasswordLabel = new Label("Jamf Pro Password:");
        JamfProPasswordLabel.setFont(font);
        JamfProPasswordLabel.setLineSpacing(20);
        GridPane.setHalignment(JamfProPasswordLabel, HPos.CENTER);
        
        Label OutputMessage = new Label("Please include https://");
        OutputMessage.setFont(font1);
        OutputMessage.setTextFill(Color.rgb(50, 60, 125));
                
        //Text Fields for processing input       
        TextField JamfProURLInput = new TextField();
        JamfProURLInput.setPromptText("");
        JamfProURLInput.setFont(font);
        GridPane.setHalignment(JamfProURLInput, HPos.CENTER);
        
        TextField JamfProUsernameInput = new TextField();
        JamfProUsernameInput.setPromptText("Jamf Pro Username ");
        JamfProUsernameInput.setFont(font);
        GridPane.setHalignment(JamfProUsernameInput, HPos.CENTER);
        
        PasswordField JamfProPasswordInput = new PasswordField();
        JamfProPasswordInput.setPromptText("Jamf Pro Password ");
        JamfProPasswordInput.setFont(font);
        GridPane.setHalignment(JamfProPasswordInput, HPos.CENTER);
        
        Button btn = new Button();
        btn.setText("Export Scope Report to .csv file");
        btn.setAlignment(Pos.BOTTOM_CENTER);    
      
//Vbox for input group
        VBox Input = new VBox(JamfProLabel, JamfProURLInput, JamfProUsernameLabel,
        JamfProUsernameInput, JamfProPasswordLabel, JamfProPasswordInput, NamesLabel);
        Input.setAlignment(Pos.TOP_CENTER);
        Input.setPadding(new Insets(10, 10, 10, 10));
        Input.setSpacing(5);
        
//Radial Buttons        ComputerGroupsButton, MobileGroupsButton, to be added soon
        HBox DeviceGroupOptions = new HBox(UserGroupsButton, MobileGroupsButton, ComputerGroupsButton);
        DeviceGroupOptions.setAlignment(Pos.CENTER);
        DeviceGroupOptions.setPadding(new Insets(10, 10, 10, 10));
        DeviceGroupOptions.setSpacing(18);
        
        //Bottom Button        
        HBox Button = new HBox(btn);
        Button.setAlignment(Pos.CENTER);
        Button.setPadding(new Insets(10, 10, 10, 10));
        Button.setSpacing(10);
            
        VBox root = new VBox();
        root.setAlignment(Pos.TOP_CENTER);
        root.getChildren().addAll(Input, DeviceGroupOptions, 
        Button, OutputMessage);
                
        Scene scene = new Scene(root, 600, 425);
        
        primaryStage.getIcons().add(new Image("file:JamfLogo.png"));
        primaryStage.setTitle("The Device Groups Tool");
        primaryStage.setScene(scene);
        primaryStage.show();
        
            btn.setOnAction((ActionEvent event) -> {                                 
            ProgressForm pForm = new ProgressForm();
    
                String url = "https://zdorow.jamfcloud.com";
                String username = "zdorow";
                String password = "ZaxsZaxs1227";
                api = new JPApiCalls(url, username, password, JPApiCalls.FORMAT.JSON, JPApiCalls.FORMAT.JSON);
                List<String> lines = Arrays.asList(url, username);
                DateTimeFormatter timeStampPattern = DateTimeFormatter.ofPattern("MM.dd.yyyy");
                
                
                //String url = JamfProURLInput.getText();
                //String username = JamfProUsernameInput.getText();
                //String password = JamfProPasswordInput.getText();
                //String devices = "mobiledevicegroups";
Task<Void> mainTask = new Task<Void>(){

            @Override
            public Void call() throws InterruptedException, JSONException {
                                    
                if (MobileGroupsButton.isSelected()){
                    try (BufferedWriter writer = new BufferedWriter(new FileWriter(timeStampPattern.format(java.time.LocalDateTime.now()) + "MobileGroupsScopeReport.csv"))) {
                                                
                        JSONObject jsonGroup = new JSONObject(api.get("mobiledevicegroups"));
                        JSONArray jsonGroupArray = jsonGroup.getJSONArray("mobile_device_groups");
                        writer.write("Total Mobile Groups are:" + jsonGroupArray.length());
                        writer.newLine();
                        
                        for(int i=0; i<jsonGroupArray.length(); i++){
                            JSONObject dataObj = (JSONObject) jsonGroupArray.get(i);
                            
                            int id = dataObj.getInt("id");
                            String name = dataObj.getString("name");
                            String[] MobileGroupsArray = name.split("name");
                            for (String MobileGroupsArray1 : MobileGroupsArray) {
                                writer.write("** Mobile Group ***" + MobileGroupsArray1 + "*** has these items Scoped: ");
                                writer.newLine(); 
            //Getting all the applcations
            JSONObject jsonMobileApps = new JSONObject(api.get("mobiledeviceapplications"));
            JSONArray jsonAppArray = jsonMobileApps.getJSONArray("mobile_device_applications");
           
            writer.write("Mobile Applications:,");
            
            //Getting the scope of all the applications
          for(int count=0; count<jsonAppArray.length(); count++){
            JSONObject dataObj2 = (JSONObject) jsonAppArray.get(count);
            int DappId = dataObj2.getInt("id");
            String AppName = dataObj2.getString("name");
            JSONObject jsonAPPScope = new JSONObject(api.get("mobiledeviceapplications/id/" + DappId + "/subset/scope"));
            
            //Checking the mobile device group scope
           JSONObject jsonGroupAPP = jsonAPPScope.getJSONObject("mobile_device_application");
           JSONObject jsonAppScope = jsonGroupAPP.getJSONObject("scope");
           JSONArray MobileGroupScopeARRAY = jsonAppScope.getJSONArray("mobile_device_groups");
           
           String MobileGroupScope = MobileGroupScopeARRAY.toString();
            // Comparing ID of the mobile device group
           
            if (!"[]".equals(MobileGroupScope)){
            
                for(int c=0; c < MobileGroupScopeARRAY.length(); c++){
                    JSONObject MobileGroupScopeObject = (JSONObject) MobileGroupScopeARRAY.get(c);
                    int ScopeDgroupId = MobileGroupScopeObject.getInt("id");
                                String MobileGroupSLIM = MobileGroupScope.replace("[", "").replace("]", "");
                                String[] MobileGroupARRAY = MobileGroupSLIM.split("name:");
                    for (String MobileGroupARRAY1 : MobileGroupARRAY) {
                        if(id == ScopeDgroupId){
                            
                            writer.write(AppName + ",");
                        }
                    }          
                            }
                    }
            }
                                

                            }
                            writer.newLine(); 
                            updateProgress(i, jsonGroupArray.length());
                        }                      

                    } catch (JPApiException | JSONException | IOException ex) {
                        OutputMessage.setText( "URL, username and/or password not accepted.");
                        Logger.getLogger(ScopeReport20.class.getName()).log(Level.SEVERE, null, ex);
                    }
                    
                }                
                updateProgress(10, 10);
                return null;
            }
            
        };
OutputMessage.setText("Writing to file " + timeStampPattern.format(java.time.LocalDateTime.now()) + "MobileGroupsScopeReport.csv");
      pForm.activateProgressBar(mainTask);
            
      mainTask.setOnSucceeded(e -> {                
                    pForm.getDialogStage().close();
                    btn.setDisable(false);
                    OutputMessage.setText("Done writing to file " + timeStampPattern.format(java.time.LocalDateTime.now()) + "MobileGroupsScopeReport.csv");
            });
      
                  btn.setDisable(true);
                  
            Thread thread = new Thread(mainTask);
            thread.start();
      });
    }
    

}